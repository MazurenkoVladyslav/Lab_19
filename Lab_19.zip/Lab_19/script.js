
const modal = document.getElementById('modal');


const btn = document.getElementById('createProductBtn');


const span = document.getElementsByClassName('close')[0];


btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}


window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}


const productForm = document.getElementById('productForm');
productForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(productForm);
    const product = {};
    formData.forEach(function(value, key) {
        product[key] = value;
    });
    console.log('New product:', product);
    modal.style.display = 'none';
});
